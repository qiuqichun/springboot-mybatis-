package com.qqc.kafka.config.druid;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.support.http.StatViewServlet;
import com.alibaba.druid.support.http.WebStatFilter;
import com.qqc.kafka.config.DsConfig;

/**
 * @author zh
 * @ClassName cn.aduu.config.DruidConfiguration
 * @Description
 */
@Configuration
public class DruidConfiguration {
	
	 @Value("${spring.datasource.initialSize}")
     private int initialSize;

     @Value("${spring.datasource.minIdle}")
     private int minIdle;

     @Value("${spring.datasource.maxActive}")
     private int maxActive;

     @Value("${spring.datasource.maxWait}")
     private int maxWait;

     @Value("${spring.datasource.timeBetweenEvictionRunsMillis}")
     private int timeBetweenEvictionRunsMillis;

     @Value("${spring.datasource.minEvictableIdleTimeMillis}")
     private int minEvictableIdleTimeMillis;

     @Value("${spring.datasource.validationQuery}")
     private String validationQuery;

     @Value("${spring.datasource.testWhileIdle}")
     private boolean testWhileIdle;

     @Value("${spring.datasource.testOnBorrow}")
     private boolean testOnBorrow;

     @Value("${spring.datasource.testOnReturn}")
     private boolean testOnReturn;

     @Value("${spring.datasource.poolPreparedStatements}")
     private boolean poolPreparedStatements;

     @Value("${spring.datasource.maxPoolPreparedStatementPerConnectionSize}")
     private int maxPoolPreparedStatementPerConnectionSize;

     @Value("${spring.datasource.filters}")
     private String filters;

     @Value("{spring.datasource.connectionProperties}")
     private String connectionProperties;

  
  	
  	@Primary
  	@Bean("sqlserverDataSource") 
  	@ConfigurationProperties(prefix = "spring.datasource."+DsConfig.SQLSERVER)
  	public DataSource SqlDataSource() {
  		DruidDataSource dataSource = new DruidDataSource();
  		try {
        	this.init(dataSource);
		} catch (Exception e) {
			
		}
        return dataSource;//注意：使用Druid
    }
  	
  	@Bean("qqcDataSource") 
  	@ConfigurationProperties(prefix = "spring.datasource."+DsConfig.QQC)
  	public DataSource dataSource() {
  		DruidDataSource dataSource = new DruidDataSource();
  		dataSource.setTestWhileIdle(false);
  		dataSource.setMinIdle(0);
         return dataSource;//注意：使用Druid
    }
	
  	
    /**<WebStatFilter>
     * 注册一个StatViewServlet
     * 
     * @return
     */
    @Bean
    public ServletRegistrationBean druidStatViewServlet() {
        // org.springframework.boot.context.embedded.ServletRegistrationBean提供类的进行注册.
        ServletRegistrationBean servletRegistrationBean =  new ServletRegistrationBean(new StatViewServlet(), "/druid/*");

        // 添加初始化参数：initParams
        // 白名单：
        /*servletRegistrationBean.addInitParameter("allow", "127.0.0.1");
        servletRegistrationBean.addInitParameter("allow", "103.13.247.73");*/
        /*servletRegistrationBean.addInitParameter("allow", "*");*/
        // IP黑名单 (存在共同时，deny优先于allow) : 如果满足deny的话提示:Sorry, you are not permitted to view this page.
        //servletRegistrationBean.addInitParameter("deny", "10.0.50.152");
        // 登录查看信息的账号密码.
        servletRegistrationBean.addInitParameter("loginUsername", "admin");
        servletRegistrationBean.addInitParameter("loginPassword", "fmbi123");
        // 是否能够重置数据.
        servletRegistrationBean.addInitParameter("resetEnable", "false");
        return servletRegistrationBean;
    }

    /**
     * 注册一个：filterRegistrationBean
     * 
     * @return
     */
    @Bean
    public FilterRegistrationBean druidStatFilter() {

        FilterRegistrationBean filterRegistrationBean =  new FilterRegistrationBean(new WebStatFilter());
        // 添加过滤规则.
        filterRegistrationBean.addUrlPatterns("/*");
        // 添加不需要忽略的格式信息.
        filterRegistrationBean.addInitParameter("exclusions", "*.js,*.gif,*.jpg,*.png,*.css,*.ico,/druid/*");
        return filterRegistrationBean;
    }

 
    private DruidDataSource init(DruidDataSource datasource) throws SQLException {
        datasource.setInitialSize(initialSize);
        datasource.setMinIdle(minIdle);
        datasource.setMaxActive(maxActive);
        datasource.setMaxWait(maxWait);
        datasource.setTimeBetweenEvictionRunsMillis(timeBetweenEvictionRunsMillis);
        datasource.setMinEvictableIdleTimeMillis(minEvictableIdleTimeMillis);
        datasource.setValidationQuery(validationQuery);
        datasource.setTestWhileIdle(testWhileIdle);
        datasource.setTestOnBorrow(testOnBorrow);
        datasource.setTestOnReturn(testOnReturn);
        datasource.setPoolPreparedStatements(poolPreparedStatements);
        datasource.setMaxPoolPreparedStatementPerConnectionSize(maxPoolPreparedStatementPerConnectionSize);
        datasource.setFilters(filters);
        datasource.setConnectionProperties(connectionProperties);
        return datasource;
    }

}