package com.qqc.kafka.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.qqc.kafka.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {


	@Autowired
	private UserService userService;
	

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	@ResponseBody
	public Object login() {
		try {
			Integer queryCount = userService.queryCount();
			Integer queryTestCount = userService.queryTestCount();
			return "发送kafka成功====>" ;
		} catch (Exception e) {
			e.printStackTrace();
			return "发送kafka失败";
		}
	}

}
