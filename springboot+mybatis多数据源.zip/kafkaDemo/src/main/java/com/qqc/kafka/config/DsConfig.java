package com.qqc.kafka.config;

/**
 * 所有数据来源
 * 
 * @author huangbijin
 * @date 2018/06/10
 */
public class DsConfig {

    //oracle数据库
    public static final String QQC = "qqc";
    //sqlserver数据库
    public static final String SQLSERVER = "sqlserver";
}
