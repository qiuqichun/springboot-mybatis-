package com.qqc.kafka.mapper.sqlserver;

public interface UserMapper {
	public Integer queryCounts();
}
