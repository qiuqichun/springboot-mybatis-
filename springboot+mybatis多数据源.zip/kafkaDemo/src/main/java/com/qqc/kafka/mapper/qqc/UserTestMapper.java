package com.qqc.kafka.mapper.qqc;

public interface UserTestMapper {
	public Integer queryCount();
}
